<?php
if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
}

if ( !class_exists('Animate_plugable') ) {

class Animate_plugables{
        function __construct(){

        }
}
}
